<form id="form1" name="form1" method="post" action="pelanggan_simpan.php">
  <table width="500" border="0" align="left">
   <tr>
      <td width="32%" align="left" valign="top">
  <a href="home.php?go=Pelanggan"><img src="gambar/Menu.png" width="32" height="32" title="Kembali" /></a>
  </td>
  </tr>
    <tr>
      <td width="32%" align="left" valign="top">No KTP</td>
      <td width="1%" align="left" valign="top">:</td>
      <td width="67%" align="left" valign="top"><input name="notxt" type="text" id="notxt" size="15" /></td>
    </tr>
    <tr>
      <td align="left" valign="top">Nama Pelanggan</td>
      <td align="left" valign="top">:</td>
      <td align="left" valign="top"><input name="nmtxt" type="text" id="nmtxt" size="35" /></td>
    </tr>
    <tr>
      <td align="left" valign="top">Alamat</td>
      <td align="left" valign="top">:</td>
      <td align="left" valign="top"><textarea name="almtxt" cols="35" rows="4" id="almtxt"></textarea></td>
    </tr>
    <tr>
      <td align="left" valign="top">Telepon</td>
      <td align="left" valign="top">:</td>
      <td align="left" valign="top"><input name="tlptxt" type="text" id="tlptxt" size="20" /></td>
    </tr>
    <tr>
      <td align="left" valign="top">Foto</td>
      <td align="left" valign="top">:</td>
      <td align="left" valign="top"><input name="foto" type="file" id="foto" readonly="readonly" /></td>
    </tr>
    <tr>
      <td align="left" valign="top">&nbsp;</td>
      <td align="left" valign="top">&nbsp;</td>
      <td align="left" valign="top"><hr /></td>
    </tr>
    <tr>
      <td align="left" valign="top">&nbsp;</td>
      <td align="left" valign="top">&nbsp;</td>
      <td align="left" valign="top"><label>
        <input type="submit" name="Submit" value="Simpan" />
        </label>
        </span></td>
    </tr>
  </table>
</form>
