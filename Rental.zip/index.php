<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Rental Kendaraan</title>
<style type="text/css">
body,td,th {
	-webkit-text-stroke: 0.4px black; /* width and color */
  color: yellow;
  font-weight: bold;
}

</style>
<link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body topmargin="100">
<table width="500" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <th scope="col"><img src="Gambar/header.png" width="500" height="100" /></th>
  </tr>
  <tr>
    <td align="center" bgcolor="#FEAF01"><b><font face="Verdana, Geneva, sans-serif" size="1" color="#000000">Aplikasi Rental Kendaraan Ver. Buku Aplikasi Bisnis dengan PHP &amp; MySQL</font></b></td>
  </tr>
  <tr>
    <td height="250" valign="middle" background="Gambar/BackTbl.png"><?php include "menu.php" ?></td>
  </tr>
  <tr>
    <td><img src="Gambar/footer.png" width="500" height="25" /></td>
  </tr>
</table>
</body>
</html>