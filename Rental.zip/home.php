<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Rental Maxi</title>
<style type="text/css">
body {
	
  background-size: 100%;
  background-attachment: scroll;
  background-repeat: no-repeat;
  background-image: url(Gambar/background.jpg);

}
.Area_Halaman {
	margin-left: 10px;
	margin-right: 10px;
	margin-bottom: 5px;
	margin-top: 10px;
}
body,td,th {
	font-family: Tahoma, Geneva, sans-serif;
	font-size: 12px;
}
</style>
</head>

<body>
<table width="950" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
  <tr>
    <th scope="col"><img src="Gambar/header menu.png" width="950" height="100" /></th>
  </tr>
  <tr>
    <td height="525" align="left" valign="top"><div class="Area_Halaman"><?php include "halaman.php" ?></div></td>
  </tr>
  <tr>
    <td><img src="Gambar/footer menu.png" width="950" height="25" /></td>
  </tr>
</table>
</body>
</html>