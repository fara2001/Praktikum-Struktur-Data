<link rel="stylesheet" type="text/css" href="css/style.css">

<table width="450" border="0" align="center" cellpadding="2" cellspacing="2" >
  <tr>
    <th width="138" scope="col" style="background-color: #00aeef;border-style: solid; border-color: #00aeef; border-width: 10%;">Master</th>
    <th width="138" scope="col" style="background-color: #00aeef;border-style: solid; border-color: #00aeef; border-width: 10%;">Transaksi</th>
     <th width="138" scope="col" style="background-color: #00aeef;border-style: solid; border-color: #00aeef; border-width: 10%;">Laporan</th>
  </tr>
  <tr>
    <th colspan="3" align="center" scope="col"><hr color="#FDD442" /></th>
  </tr>
  <tr>
    <th align="center" scope="col"><a href="home.php?go=Kendaraan"><img src="Gambar/car.png" width="48" height="48"></a></th>
    <th align="center" scope="col"><a href="home.php?go=Sewa"><img src="Gambar/keluar.png" width="48" height="48"></a></th>
    <th align="center" scope="col"><a href="home.php?go=Laporan"><img src="Gambar/laporan transaksi.png" width="48" height="48"></a></th>
  </tr>
  <tr>
     <th width="138" scope="col" style="background-color: #00aeef;border-style: solid; border-color: #00aeef; border-width: 10%;">Kendaraan</td>
     <th width="138" scope="col" style="background-color: #00aeef;border-style: solid; border-color: #00aeef; border-width: 10%;">Sewa</td>
     <th width="138" scope="col" style="background-color: #00aeef;border-style: solid; border-color: #00aeef; border-width: 10%;">Laporan sewa</td>
  </tr>
  <tr>
    <td align="center"><a href="home.php?go=Pelanggan"><img src="Gambar/pelanggan.png" width="48" height="48"></td>
    <td align="center"><a href="home.php?go=Kembali"><img src="Gambar/masuk.png" width="48" height="48"></a></td>
    <td align="center">&nbsp;</td>
  </tr>
  <tr>
    <th width="138" scope="col" style="background-color: #00aeef;border-style: solid; border-color: #00aeef; border-width: 10%;">Pelanggan</td>
     <th width="138" scope="col" style="background-color: #00aeef;border-style: solid; border-color: #00aeef; border-width: 10%;">Kembali</td>
    <td align="center">&nbsp;</td>
  </tr>
  <tr>
    <td align="center">&nbsp;</td>
    <td align="center">&nbsp;</td>
    <td align="center">&nbsp;</td>
  </tr>
</table>
