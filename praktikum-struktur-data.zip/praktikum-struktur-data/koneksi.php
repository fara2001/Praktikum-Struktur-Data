<?php
$srvr="localhost"; //SESUAIKAN DENGAN WEBSERVER ANDA
$db="rasd5145_prak_st"; //SESUAIKAN DENGAN WEBSERVER ANDA
$usr="rasd5145_prakst"; //SESUAIKAN DENGAN WEBSERVER ANDA
$pwd="PraktikumStrukturData5";//SESUAIKAN DENGAN WEBSERVER ANDA

mysql_connect($srvr,$usr,$pwd);
mysql_select_db($db);
?>